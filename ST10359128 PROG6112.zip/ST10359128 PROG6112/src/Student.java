/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package st10359128.prog6112;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Student {
    public final static Scanner kb = new Scanner(System.in);
    
   static ST10359128PROG6112 college = new ST10359128PROG6112();
    
    public static ArrayList<Integer> ID = new ArrayList<>();
    public static ArrayList<String> name = new ArrayList<>();
    public static ArrayList<Integer> age = new ArrayList<>();
    public static ArrayList<String> email = new ArrayList<>();
    public static ArrayList<String> course = new ArrayList<>();
    
    public void SaveStudent() { 
        System.out.println("CAPTURE A NEW STUDENT\n"
            + "****************************************");
     
        System.out.print("Enter the student ID: ");
        int identification = kb.nextInt();
        ID.add(identification);
        
        kb.nextLine(); 
        
        System.out.print("Enter the student name: ");
        String studentName = kb.nextLine();
        name.add(studentName);
        
        int ageRestriction = 16;
        int studentAge;
        
        do {
            try {
                System.out.print("Enter the student age: ");
                studentAge = kb.nextInt();

                if (studentAge < ageRestriction) {
                    System.out.println("You have entered an incorrect age!!!\n"
                            + "Age should be greater than or equal to " + ageRestriction + "\n"
                            + "Please re-enter the student age >>");
                } else {
                    age.add(studentAge);
                }
            } catch (InputMismatchException e) {
                System.out.println("You have entered an incorrect age!!!\n"
                        + "Age should be greater than or equal to " + ageRestriction + "\n"
                        + "Please re-enter the student age >>");
                kb.nextLine(); 
                studentAge = -1; 
            }
        } while (studentAge < ageRestriction);

        kb.nextLine();
        
        String studentEmail;
        do {
            System.out.print("Enter the student email: ");
            studentEmail = kb.nextLine();

            if (!studentEmail.contains("@")) {
                System.out.println("Email must contain '@' symbol.");
            } else {
                email.add(studentEmail);
            }
        } while (!studentEmail.contains("@"));
        
        System.out.print("Enter the student course: ");
        String studentCourse = kb.nextLine();
        course.add(studentCourse);
        
        System.out.println("The student details have been successfully saved.");
        System.out.println("Enter (1) to launch menu or any other key to exit");
        
        college.menuLaunch(kb);
    }
   
    public static String SearchStudent(int studentId) {
        String val=null;
        if (ID.isEmpty()) {
            System.out.println("Student database empty.");
            System.out.println("----------------------------------------");
            System.out.println("Enter (1) to launch menu or any other key to exit");
            college.menuLaunch(kb);
            val=null; 
        }

        System.out.print("Enter the student ID to search: ");
        studentId = kb.nextInt();
        System.out.println("----------------------------------------");
        
        boolean found = false; 

        for (int i = 0; i < ID.size(); i++) {
            if (ID.get(i) == studentId) {
                System.out.println("STUDENT ID: " + ID.get(i) + "\n"
                        + "STUDENT NAME: " + name.get(i) + "\n"
                        + "STUDENT AGE: " + age.get(i) + "\n"
                        + "STUDENT EMAIL: " + email.get(i) + "\n"
                        + "STUDENT COURSE: " + course.get(i));
                found = true; 
                val="found";
                break;
            }
        }

        if (!found) {
            System.out.print("Student with student ID: " + studentId + " was not found!" + "\n");
        }

        System.out.println("----------------------------------------");
        System.out.println("Enter (1) to launch menu or any other key to exit");
        college.menuLaunch(kb);
        
        return val;
    }
    public void DeleteStudent(Scanner kb) {
        if (ID.isEmpty()) {
        System.out.println("Student database empty.");
        System.out.println("----------------------------------------");
        System.out.println("Enter (1) to launch menu or any other key to exit");
        college.menuLaunch(kb);
        }

   

        System.out.print("Enter the ID to delete: ");
        int IDremove = kb.nextInt();
        System.out.println("----------------------------------------");

        boolean found = false; 
        boolean cancel = false;
        boolean correctOption = false;
        
        for (int i = 0; i < ID.size(); i++) {
            if (ID.get(i) == IDremove) {
                while(!correctOption) {
                System.out.println("Are you sure you want to delete " + ID.get(i) + " from the system? Yes (y) to delete or No (n) to cancel.");
                String deleteConfirmation = kb.next();
                
                switch (deleteConfirmation.toLowerCase()) {
                    case "y" ->
                    {
                        ID.remove(i);
                        name.remove(i);
                        age.remove(i);
                        email.remove(i);
                        course.remove(i);
                        found = true;
                        correctOption = true;
                        break;
                    }
                    case "n" ->
                    {
                        System.out.println("----------------------------------------");
                        cancel = true;
                        correctOption = true;
                        break;
                    }
                    default -> System.out.println("Please enter only one of the following options: \"y\" or \"n\": ");
                }
             }
           }
        }
        
       

        if (found) {
            System.out.println("The student details have been deleted successfully.");
        } else if (cancel) {
            System.out.println("Deletion aborted...");
        }
        else {
            System.out.println("Student with ID " + IDremove + " not found.");
        }

        System.out.println("----------------------------------------");
        System.out.println("Enter (1) to launch menu or any other key to exit");
        
        college.menuLaunch(kb);
    }
    
    public void StudentReport(Scanner kb) {  
        if (ID.isEmpty()) {
            System.out.println("Student database empty.");
            System.out.println("----------------------------------------");
            System.out.println("Enter (1) to launch menu or any other key to exit");
            college.menuLaunch(kb);
        }
        
        for (int i = 0; i < ID.size(); i++)
        {
            System.out.println("\nSTUDENT " + (i+1) + "\n"
                    + "----------------------------------------\n"
                    + "STUDENT ID: " + ID.get(i) + "\n"
                    + "STUDENT NAME: " + name.get(i) + "\n" 
                    + "STUDENT AGE: " + age.get(i) + "\n"
                    + "STUDENT EMAIL: " + email.get(i) + "\n"
                    + "STUDENT COURSE: " + course.get(i));
        }
        
        System.out.println("----------------------------------------");
        System.out.println("Enter (1) to launch menu or any other key to exit");
        college.menuLaunch(kb);
    }
    
    public void ExitStudentApplication(Scanner kb) {
        System.out.println("Thank you for using the Student Management Application!");
        System.out.println("Exiting program...");
        System.exit(0);
    }
}

