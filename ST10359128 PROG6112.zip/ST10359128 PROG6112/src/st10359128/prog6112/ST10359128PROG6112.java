/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package st10359128.prog6112;

/**
 *
 * @author lab_services_student
 */
public class ST10359128PROG6112 {

    /**
     * @param args the command line arguments
     */
     public static void main(String[] args) {
       ST10359128PROG6112 method = new ST10359128PROG6112();
        System.out.println("STUDENT MANAGEMENT APPLICATION\n"
                + "****************************************\n"
                + "Enter (1) to launch menu or any other key to exit");
        method.menuLaunch(kb);
    }
    
    public void menuLaunch(Scanner kb) {
        int onlyOne = 1;    
        int menuStart;
        
      
        Student student = new Student();
        ST10359128PROG6112 method = new ST10359128PROG6112();
        
        if (kb.hasNextInt()) {
            menuStart = kb.nextInt();
            switch (menuStart) {
                case 1: menuItems(kb); break; 
                default: student.ExitStudentApplication(kb); break; 
            }
        } else {
            student.ExitStudentApplication(kb);  
        }
        
    }
    
    public void menuItems(Scanner kb) {
        int menuChoice;
        boolean notRegistered = false;
        
        Student student = new Student();
        
        while(!notRegistered) {
        System.out.println("Please select one of the following menu items: \n"
                        + "(1) Capture a new Student.\n"
                        + "(2) Search for a student.\n"
                        + "(3) Delete a student.\n"
                        + "(4) Print student report.\n"
                        + "(5) Exit Application.");
        
        menuChoice = kb.nextInt();
        
        switch(menuChoice) {
            case 1: student.SaveStudent(); notRegistered = true; break; 
            case 2: student.SearchStudent(menuChoice); notRegistered = true; break;
            case 3: student.DeleteStudent(kb); notRegistered = true; break;
            case 4: student.StudentReport(kb); notRegistered = true; break;
            case 5: student.ExitStudentApplication(kb); notRegistered = true; break;
            default: System.out.println("Please enter a valid option!!!"); break;
        }
      } 
    }
    
}
