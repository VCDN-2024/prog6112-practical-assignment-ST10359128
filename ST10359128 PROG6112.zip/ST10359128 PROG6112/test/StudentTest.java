/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.InputMismatchException;
import java.util.Scanner;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import st10359128.prog6112.Student;

/**
 *
 * @author lab_services_student
 */
public class StudentTest {
    private Student student;
    private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
    private final PrintStream originalOut = System.out;
    
    @Before
    public void setUp() {
        student = new Student();
    }

    @After
    public void restoreStreams() {
        System.setOut(originalOut);
    }
    
    @Test
    public void TestSaveStudent() {
        int testId = 123;
        String testName = "John Doe";
        int testAge = 18;
        String testEmail = "johndoe@example.com";
        String testCourse = "Computer Science";

       
       Student mo = new Student();
       Student.ID.add(123);
       Student.age.add(18);
       Student.course.add("Computer Science");
       Student.email.add("johndoe@example.com");
       Student.name.add( "John Doe");

        assertEquals(1, Student.ID.size());
        assertEquals(1, Student.name.size());
        assertEquals(1, Student.age.size());
        assertEquals(1, Student.email.size());
        assertEquals(1, Student.course.size());

        assertEquals(testName, Student.name.get(0));
        assertEquals(testEmail, Student.email.get(0));
        assertEquals(testCourse, Student.course.get(0));
    }
    
    @Test
    public void TestSearchStudent() {



Student stu = new Student ();

stu.ID.add(321);
stu.name.add("Reginal");
stu.age.add(16);
stu.email.add("reginal@gmail.com");
stu.course.add("BCAD");


String found= stu. SearchStudent(321);
assertNotNull(found);


    }

    @Test
    public void TestSearchStudent_StudentNotFound() {
        Student student = new Student();
        
        Student.ID.clear();
        Student.name.clear();
        Student.age.clear();
        Student.email.clear();
        Student.course.clear();
        
        ByteArrayOutputStream outContent = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent));
        
        student.SearchStudent(0);
        
        String expectedOutput = "Student with student ID: 123 was not found!";
        assertTrue(outContent.toString().contains(expectedOutput));
        
        System.setOut(System.out);
    }

    @Test
    public void TestDeleteStudent() {
        Student.ID.add(1); 
        Student.name.add("John"); 
        Student.age.add(20);
        Student.email.add("john@example.com"); 
        Student.course.add("Math");

        Scanner scanner = new Scanner("123");
        student.DeleteStudent(scanner);

        assertFalse(Student.ID.contains(1));
        assertFalse(Student.name.contains("John"));
        assertFalse(Student.age.contains(20));
        assertFalse(Student.email.contains("john@example.com"));
        assertFalse(Student.course.contains("Math"));
    }

    @Test
    public void TestDeleteStudent_StudentNotFound() {
        Student student = new Student();

        Student.ID.add(1);
        Student.ID.add(2);
        Student.ID.add(3);


        ByteArrayOutputStream outContent = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent));

        Scanner scanner = new Scanner("123");
        student.DeleteStudent(scanner);

        System.setOut(System.out);

        String expectedMessage = "Student with ID 0 not found.";
        assertEquals(expectedMessage, outContent.toString().trim());
    }
    
    @Test
    public void TestStudentAge_StudentAgeValid() {
        Student.ID.add(1);
        Student.name.add("John");
        Student.age.add(20); // Valid age
        Student.email.add("john@example.com");
        Student.course.add("Computer Science");

        String input = "1\n"; 
        System.setIn(new java.io.ByteArrayInputStream(input.getBytes()));

        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outputStream));

        student.SearchStudent(0);

        String expectedOutput = "STUDENT ID: 1\n" +
                "STUDENT NAME: John\n" +
                "STUDENT AGE: 20\n" +
                "STUDENT EMAIL: john@example.com\n" +
                "STUDENT COURSE: Computer Science\n";
        assertEquals(expectedOutput, outputStream.toString());

        System.setIn(System.in);
        System.setOut(System.out);
    }
    
    @Test
    public void TestStudentAge_StudentAgeInvalid() {
        Student.ID.add(1);
        Student.name.add("John");
        Student.age.add(15); 
        Student.email.add("john@example.com");
        Student.course.add("Computer Science");

        ByteArrayOutputStream outContent = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent));

        student.SearchStudent(0);

        String expectedOutput = "Student with student ID: 1 was not found!\n";
        assertTrue(outContent.toString().contains(expectedOutput));
    }
    
    @Test
    public void TestStudentAge_StudentAgeInvalidCharacter() {
        student.age.clear(); 
        student.age.add(25); 
        student.age.add(20); 
        student.age.add(21); 
        
        student.age.add(Integer.parseInt("abc"));
        
        try {
            student.SearchStudent(0);
            fail("Expected InputMismatchException");
        } catch (InputMismatchException e) {
            assertEquals("InputMismatchException", e.getClass().getSimpleName());
        }
    }
    
    @Test
    public void testSearcch(){
Student stu = new Student ();

stu.ID.add(321);
stu.name.add("Reginal");
stu.age.add(16);
stu.email.add("reginal@gmail.com");
stu.course.add("BCAD");


String found= stu. SearchStudent(321);
assertNotNull(found);


    }
}
